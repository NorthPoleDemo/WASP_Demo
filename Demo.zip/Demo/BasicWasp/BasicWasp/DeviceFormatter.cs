﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using NorthPoleEngineering.WaspClassLibrary;
using NorthPoleEngineering.WaspClassLibrary.Bluetooth;

namespace BasicWasp
{
    /// <summary>
    /// This class receives a specific ANT object and formats it for display
    /// </summary>
    class DeviceFormatter
    {
        /// <summary>
        ///  List of known ANT/BLE devices
        /// </summary>
        readonly List<string> _knownDevices = new List<string> {
        "BikeCadenceSensor",
        "BikePowerSensor",
        "BikeSpeedAndCadenceSensor",
        "BikeSpeedSensor",
        "EnvironmentSensor",
        "FitnessEquipment",
        "Geocache",
        "HeartRateMonitor",
        "PairingPod",
        "PolarH7HeartRateMonitors",
        "SuuntoHeartRateMonitors",
        "UnknownDevice",
        "WFKickr"
        };

        /// <summary>
        /// Returns a dictionary of data from the device passed in
        /// </summary>
        /// <param name="device">Device sending data</param>
        /// <param name="args">arguments provided</param>
        /// <returns></returns>
        public static List<string> FormatDevice(AntDevice device, EventArgs args)
        {
            try
            {
                object[] parameters = { device, args };
                return (List<string>)typeof(DeviceFormatter).InvokeMember(
                    "Format" + device.DeviceType.ToString(),
                    BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Static,
                    null,
                    null,
                    parameters);
            }
            catch(MissingMethodException )
            {
                return new List<string> { "Unknown device" ,  "Type: "+ device.DeviceType.ToString() };
            }
        }

        /// <summary>
        /// Returns a list of user-pertinent data from the heart rate monitor
        /// </summary>
        /// <param name="h">HeartRateMonitor device</param>
        /// <param name="a">Device arguments</param>
        /// <returns></returns>
        public static List<string> FormatHeartRateMonitor(object h, object a)
        {
            HeartRateMonitor hrm = h as HeartRateMonitor;
            List<string> data = new List<string>();
            data.Add("ID: " + hrm.ExtendedDeviceNumber.ToString());
            data.Add("Type: " + hrm.DeviceType.ToString());

            HeartRateMonitorMessageEventArgs args = a as HeartRateMonitorMessageEventArgs;
            if (args != null)
            {
                data.Add("Heartrate: "+ args.FormattedHeartRate(true));
            }

            return data;
        }

        /// <summary>
        /// Returns a list of user-pertinent data from the BikeSpeedSensor
        /// </summary>
        /// <param name="h">BikeSpeedSensor device</param>
        /// <param name="a">Device arguments</param>
        /// <returns></returns>
        public static List<string> FormatBikeSpeedSensor(object h, object a)
        {
            BikeSpeedSensor hrm = h as BikeSpeedSensor;
            List<string> data = new List<string>();
            data.Add("ID: " + hrm.ExtendedDeviceNumber.ToString());
            data.Add("Type: " + hrm.DeviceType.ToString());

            BikeSpeedMessageEventArgs args = a as BikeSpeedMessageEventArgs;
            if (args != null)
            {
                data.Add(string.Format("Speed: {0:F1}", args.InstantaneousSpeed));
                data.Add("Revs: " + args.AccumulatedRevolutionCount.ToString());
            }

            return data;
        }

        /// <summary>
        /// Display data for unknown ANT sensor types
        /// </summary>
        /// <param name="j"></param>
        /// <param name="a"></param>
        /// <returns></returns>
        public static List<string> FormatUnknownSensor(object j, object a)
        {
            return new List<string> { "Unknown device", "Type: Unknown"};
        }

    }
}
